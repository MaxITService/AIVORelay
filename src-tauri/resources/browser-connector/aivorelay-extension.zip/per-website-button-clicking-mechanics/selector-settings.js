'use strict';

(() => {
  const DEFAULT_SITE_SELECTORS = Object.freeze({
    ChatGPT: Object.freeze({
      sendButtons: Object.freeze([
        'button[data-testid="send-button"]',
        'button[data-testid*="send"]',
        'button[aria-label="Send message"]',
        'button[aria-label*="Send"]',
        'form button[type="submit"]',
        'button[type="submit"]'
      ]),
      editors: Object.freeze([
        '#prompt-textarea[contenteditable="true"]',
        'div#prompt-textarea[contenteditable="true"]',
        'div[data-testid="composer-text-input"] [contenteditable="true"]',
        'div[contenteditable="true"][data-testid="prompt-textarea"]',
        'div[contenteditable="true"]#prompt-textarea',
        'div.ProseMirror#prompt-textarea',
        'div.ProseMirror[contenteditable="true"]',
        'div[contenteditable="true"].ProseMirror',
        'textarea#prompt-textarea',
        'textarea'
      ]),
      stopButtons: Object.freeze([
        'button[data-testid="stop-button"]',
        'button[data-testid*="stop"]',
        'button[aria-label="Stop generating"]',
        'button[aria-label*="Stop"]'
      ])
    }),
    Perplexity: Object.freeze({
      sendButtons: Object.freeze([
        'button[data-testid="submit-button"][aria-label="Submit"]',
        'button[data-testid="submit-button"]',
        'button[type="button"][aria-label="Submit"]',
        'button[aria-label="Submit"]',
        'button[aria-label*="Ask"]'
      ]),
      editors: Object.freeze([
        'div#ask-input[contenteditable="true"]',
        'div[contenteditable="true"][data-lexical-editor="true"]',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]'
      ]),
      stopButtons: Object.freeze([
        'button[aria-label="Stop"]',
        'button[aria-label*="Stop"]',
        'button[data-testid="stop-button"]'
      ])
    }),
    Gemini: Object.freeze({
      sendButtons: Object.freeze([
        'button[aria-label="Send message"]',
        'button[aria-label*="Send"]',
        'button[data-testid="send-button"]',
        'div.send-button-container button'
      ]),
      editors: Object.freeze([
        'div[contenteditable="true"].ql-editor',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]',
        '.ql-editor'
      ]),
      stopButtons: Object.freeze([
        'button[aria-label="Stop generating"]',
        'button[aria-label*="Stop"]',
        'button[data-testid="stop-button"]'
      ])
    }),
    Claude: Object.freeze({
      sendButtons: Object.freeze([
        'button[aria-label="Send Message"]',
        'button[aria-label="Send message"]',
        'button[aria-label*="Send"]',
        'fieldset button[type="button"]'
      ]),
      editors: Object.freeze([
        'div.ProseMirror[contenteditable="true"]',
        'div[contenteditable="true"].ProseMirror',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]'
      ]),
      stopButtons: Object.freeze([
        'button[aria-label="Stop Response"]',
        'button[aria-label="Stop response"]',
        'button[aria-label*="Stop"]'
      ])
    }),
    Grok: Object.freeze({
      sendButtons: Object.freeze([
        'button[aria-label="Submit"]',
        'button[aria-label*="Send"]',
        'button[type="submit"]'
      ]),
      editors: Object.freeze([
        'textarea[placeholder*="Ask"]',
        'textarea',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]'
      ]),
      stopButtons: Object.freeze([
        'button[aria-label="Stop"]',
        'button[aria-label="Stop generating"]',
        'button[aria-label*="Stop"]'
      ])
    }),
    AIStudio: Object.freeze({
      sendButtons: Object.freeze([
        'button[aria-label="Run"]',
        'button[aria-label*="Run"]',
        'button[mattooltip="Run"]',
        'button.run-button'
      ]),
      editors: Object.freeze([
        'textarea.prompt-textarea',
        'textarea[aria-label*="prompt"]',
        'textarea'
      ]),
      stopButtons: Object.freeze([
        'button[aria-label="Stop"]',
        'button[aria-label*="Stop"]'
      ])
    })
  });

  const SITE_LABELS = Object.freeze({
    ChatGPT: 'ChatGPT',
    Perplexity: 'Perplexity',
    Gemini: 'Gemini',
    Claude: 'Claude',
    Grok: 'Grok',
    AIStudio: 'AI Studio'
  });

  const SELECTOR_FIELDS = Object.freeze([
    { key: 'editors', label: 'Editor selectors' },
    { key: 'sendButtons', label: 'Send button selectors' },
    { key: 'stopButtons', label: 'Stop button selectors' }
  ]);

  const SUPPORTED_SITES = Object.freeze(Object.keys(DEFAULT_SITE_SELECTORS));

  const DEFAULT_SELECTOR_SETTINGS = Object.freeze({
    heuristics: Object.freeze({
      editor: true,
      sendButton: true,
      stopButton: true
    }),
    customSelectors: Object.freeze({})
  });

  function uniqueList(values) {
    return [...new Set(values)];
  }

  function normalizeSelectorList(value) {
    if (!Array.isArray(value)) return [];
    return uniqueList(
      value
        .map((entry) => (typeof entry === 'string' ? entry.trim() : ''))
        .filter(Boolean)
    );
  }

  function normalizeSiteSelectors(value) {
    return {
      editors: normalizeSelectorList(value?.editors),
      sendButtons: normalizeSelectorList(value?.sendButtons),
      stopButtons: normalizeSelectorList(value?.stopButtons)
    };
  }

  function normalizeSelectorSettings(value) {
    const heuristics = value?.heuristics && typeof value.heuristics === 'object' ? value.heuristics : {};
    const customSelectors = value?.customSelectors && typeof value.customSelectors === 'object'
      ? value.customSelectors
      : {};
    const normalizedCustomSelectors = {};

    for (const site of SUPPORTED_SITES) {
      if (customSelectors[site]) {
        normalizedCustomSelectors[site] = normalizeSiteSelectors(customSelectors[site]);
      }
    }

    return {
      heuristics: {
        editor: heuristics.editor !== false,
        sendButton: heuristics.sendButton !== false,
        stopButton: heuristics.stopButton !== false
      },
      customSelectors: normalizedCustomSelectors
    };
  }

  function cloneSiteSelectors(value) {
    return {
      editors: [...(value?.editors || [])],
      sendButtons: [...(value?.sendButtons || [])],
      stopButtons: [...(value?.stopButtons || [])]
    };
  }

  function getDefaultSiteSelectors(site) {
    return cloneSiteSelectors(DEFAULT_SITE_SELECTORS[site] || {});
  }

  function mergeSelectorLists(primary, fallback) {
    return uniqueList([...(primary || []), ...(fallback || [])]);
  }

  function getEffectiveSiteSelectors(site, settings) {
    const normalized = normalizeSelectorSettings(settings);
    const defaults = getDefaultSiteSelectors(site);
    const custom = cloneSiteSelectors(normalized.customSelectors[site]);

    return {
      editors: mergeSelectorLists(custom.editors, defaults.editors),
      sendButtons: mergeSelectorLists(custom.sendButtons, defaults.sendButtons),
      stopButtons: mergeSelectorLists(custom.stopButtons, defaults.stopButtons)
    };
  }

  function selectorsToTextarea(value) {
    return Array.isArray(value) ? value.join('\n') : '';
  }

  function textareaToSelectors(value) {
    if (typeof value !== 'string') return [];
    return uniqueList(
      value
        .split(/\r?\n/)
        .map((entry) => entry.trim())
        .filter(Boolean)
    );
  }

  window.AivoRelaySelectorShared = {
    DEFAULT_SITE_SELECTORS,
    DEFAULT_SELECTOR_SETTINGS,
    SELECTOR_FIELDS,
    SITE_LABELS,
    SUPPORTED_SITES,
    getDefaultSiteSelectors,
    getEffectiveSiteSelectors,
    mergeSelectorLists,
    normalizeSelectorSettings,
    normalizeSiteSelectors,
    selectorsToTextarea,
    textareaToSelectors
  };
})();
