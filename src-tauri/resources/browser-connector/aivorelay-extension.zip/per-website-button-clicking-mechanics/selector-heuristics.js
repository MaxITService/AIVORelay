'use strict';

(() => {
  const shared = window.AivoRelaySelectorShared;
  if (!shared) {
    return;
  }

  let selectorSettingsCache = shared.normalizeSelectorSettings(shared.DEFAULT_SELECTOR_SETTINGS);
  let selectorSettingsLoaded = false;
  let selectorSettingsPromise = null;
  let storageListenerRegistered = false;

  const EDITOR_HINTS = {
    ChatGPT: ['prompt', 'composer', 'message', 'chat'],
    Perplexity: ['ask', 'search', 'message'],
    Gemini: ['message', 'prompt', 'ask'],
    Claude: ['message', 'prompt'],
    Grok: ['ask', 'grok', 'message'],
    AIStudio: ['prompt', 'run', 'message']
  };

  const SEND_POSITIVE_KEYWORDS = ['send', 'submit', 'ask', 'run', 'go', 'arrow', 'reply'];
  const SEND_NEGATIVE_KEYWORDS = ['stop', 'cancel', 'attach', 'upload', 'image', 'photo', 'file', 'voice', 'mic'];
  const STOP_POSITIVE_KEYWORDS = ['stop', 'cancel', 'abort', 'pause'];
  const STOP_NEGATIVE_KEYWORDS = ['send', 'submit', 'attach', 'upload', 'voice', 'mic'];

  function logHeuristic(...args) {
    if (typeof logConCgp === 'function') {
      logConCgp('[selectors]', ...args);
    }
  }

  function isOurOverlayElement(element) {
    if (!element || typeof element.closest !== 'function') return false;
    return Boolean(
      element.closest('#hc-floating-ui') ||
      element.closest('.aivo-popup-root') ||
      element.closest('[data-aivorelay-popup="true"]')
    );
  }

  function isVisibleElement(element) {
    if (!element || isOurOverlayElement(element)) return false;
    if (window.MaxExtensionUtils?.isElementVisible) {
      return window.MaxExtensionUtils.isElementVisible(element);
    }
    const rect = element.getBoundingClientRect();
    if (!rect || rect.width < 2 || rect.height < 2) return false;
    const style = window.getComputedStyle(element);
    if (!style) return false;
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const opacity = Number.parseFloat(style.opacity || '1');
    return Number.isNaN(opacity) || opacity !== 0;
  }

  function isEditableElement(element) {
    if (!element || !isVisibleElement(element)) return false;
    if (element instanceof HTMLTextAreaElement) {
      return !element.disabled && !element.readOnly;
    }
    const role = element.getAttribute?.('role') || '';
    const contentEditable = element.isContentEditable || element.getAttribute?.('contenteditable') === 'true';
    if (!contentEditable && role !== 'textbox') {
      return false;
    }
    if (element.getAttribute?.('aria-disabled') === 'true') return false;
    return true;
  }

  function isButtonElement(element) {
    if (!element || !isVisibleElement(element)) return false;
    const tag = element.tagName?.toLowerCase?.() || '';
    if (tag === 'button') return true;
    const role = element.getAttribute?.('role') || '';
    return role === 'button' || Boolean(element.getAttribute?.('onclick'));
  }

  function getElementTextMeta(element) {
    const values = [
      element.getAttribute?.('aria-label'),
      element.getAttribute?.('title'),
      element.getAttribute?.('placeholder'),
      element.getAttribute?.('data-testid'),
      element.getAttribute?.('name'),
      element.getAttribute?.('id'),
      element.textContent
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    return values;
  }

  function scoreKeywordMatch(text, positiveKeywords, negativeKeywords) {
    let score = 0;
    for (const keyword of positiveKeywords) {
      if (text.includes(keyword)) {
        score += 14;
      }
    }
    for (const keyword of negativeKeywords) {
      if (text.includes(keyword)) {
        score -= 18;
      }
    }
    return score;
  }

  function collectShadowRoots(root, bucket) {
    const nodes = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (const node of nodes) {
      if (node?.shadowRoot) {
        bucket.push(node.shadowRoot);
        collectShadowRoots(node.shadowRoot, bucket);
      }
    }
  }

  function collectRoots() {
    const roots = [document];
    collectShadowRoots(document, roots);
    return roots;
  }

  function querySelectorList(selectors, filterFn) {
    for (const selector of selectors || []) {
      if (!selector) continue;
      let nodes = [];
      try {
        nodes = document.querySelectorAll(selector);
      } catch (err) {
        logHeuristic('Invalid selector skipped', selector, err?.message || err);
        continue;
      }
      for (const node of nodes) {
        if (!filterFn || filterFn(node)) {
          return node;
        }
      }
    }
    return null;
  }

  function getActiveSite() {
    return window.InjectionTargetsOnWebsite?.activeSite || 'Unknown';
  }

  function registerStorageListener() {
    if (storageListenerRegistered || !chrome?.storage?.onChanged) return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.selectorSettings) return;
      selectorSettingsCache = shared.normalizeSelectorSettings(changes.selectorSettings.newValue);
      selectorSettingsLoaded = true;
    });
    storageListenerRegistered = true;
  }

  async function ensureSelectorSettingsLoaded() {
    registerStorageListener();
    if (selectorSettingsLoaded) {
      return selectorSettingsCache;
    }
    if (!selectorSettingsPromise) {
      selectorSettingsPromise = chrome.storage.local
        .get({ selectorSettings: shared.DEFAULT_SELECTOR_SETTINGS })
        .then(({ selectorSettings }) => {
          selectorSettingsCache = shared.normalizeSelectorSettings(selectorSettings);
          selectorSettingsLoaded = true;
          return selectorSettingsCache;
        })
        .catch(() => {
          selectorSettingsLoaded = true;
          return selectorSettingsCache;
        });
    }
    return selectorSettingsPromise;
  }

  function collectEditableCandidates() {
    const roots = collectRoots();
    const seen = new Set();
    const candidates = [];

    for (const root of roots) {
      const nodes = root.querySelectorAll
        ? root.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')
        : [];
      for (const node of nodes) {
        if (seen.has(node) || !isEditableElement(node)) continue;
        seen.add(node);
        candidates.push(node);
      }
    }

    return candidates;
  }

  function collectButtonCandidates() {
    const roots = collectRoots();
    const seen = new Set();
    const candidates = [];

    for (const root of roots) {
      const nodes = root.querySelectorAll
        ? root.querySelectorAll('button, [role="button"], div[onclick], span[onclick]')
        : [];
      for (const node of nodes) {
        if (seen.has(node) || !isButtonElement(node)) continue;
        seen.add(node);
        candidates.push(node);
      }
    }

    return candidates;
  }

  function scoreEditorCandidate(element, site) {
    const rect = element.getBoundingClientRect();
    const textMeta = getElementTextMeta(element);
    const hintKeywords = EDITOR_HINTS[site] || ['message', 'prompt', 'ask'];
    let score = 0;

    score += Math.min(rect.width, 900) / 22;
    score += Math.min(rect.height, 240) / 14;
    score += Math.max(0, rect.bottom) / 65;

    if (element instanceof HTMLTextAreaElement) score += 18;
    if (element.isContentEditable || element.getAttribute?.('contenteditable') === 'true') score += 20;
    if (element.getAttribute?.('role') === 'textbox') score += 8;
    if (element.closest?.('form')) score += 8;
    if (element.closest?.('footer, main, section')) score += 4;
    if (element.id === 'prompt-textarea') score += 40;
    if (textMeta.includes('prosemirror')) score += 20;
    if (textMeta.includes('lexical')) score += 12;

    for (const keyword of hintKeywords) {
      if (textMeta.includes(keyword)) {
        score += 12;
      }
    }

    if (textMeta.includes('search')) score -= 8;
    if (textMeta.includes('upload')) score -= 12;
    if (element.closest?.('header, nav, aside')) score -= 18;

    return score;
  }

  function findEditorHeuristically(site) {
    const candidates = collectEditableCandidates();
    if (!candidates.length) return null;

    const best = candidates
      .map((element) => ({ element, score: scoreEditorCandidate(element, site) }))
      .sort((left, right) => right.score - left.score)[0];

    if (best?.score > 18) {
      logHeuristic('Editor heuristic matched', site, best.score, best.element);
      return best.element;
    }

    return null;
  }

  function getEditorAnchor(site, effectiveSelectors) {
    return querySelectorList(effectiveSelectors.editors, isEditableElement) || findEditorHeuristically(site);
  }

  function scoreButtonCandidate(element, mode, editorAnchor) {
    const rect = element.getBoundingClientRect();
    const textMeta = getElementTextMeta(element);
    const positive = mode === 'stop' ? STOP_POSITIVE_KEYWORDS : SEND_POSITIVE_KEYWORDS;
    const negative = mode === 'stop' ? STOP_NEGATIVE_KEYWORDS : SEND_NEGATIVE_KEYWORDS;
    let score = scoreKeywordMatch(textMeta, positive, negative);

    if (element.querySelector?.('svg')) score += 10;
    if (element.tagName?.toLowerCase?.() === 'button') score += 8;
    if (element.getAttribute?.('type') === 'submit') score += mode === 'send' ? 20 : -10;
    if (element.disabled || element.getAttribute?.('aria-disabled') === 'true') {
      score += mode === 'send' ? 6 : -4;
    }
    if (/^\d+$/.test((element.textContent || '').trim())) {
      score -= 20;
    }

    if (editorAnchor) {
      const editorRect = editorAnchor.getBoundingClientRect();
      const horizontalDelta = rect.left - editorRect.left;
      const verticalDelta = rect.top - editorRect.top;

      if (rect.top >= editorRect.top - 40 && rect.bottom <= editorRect.bottom + 140) score += 10;
      if (horizontalDelta >= -80) score += 6;
      if (verticalDelta >= -40) score += 4;
      if (element.closest?.('form') && editorAnchor.closest?.('form') && element.closest('form') === editorAnchor.closest('form')) {
        score += 18;
      }
    }

    return score;
  }

  function findButtonHeuristically(site, mode, effectiveSelectors) {
    const editorAnchor = getEditorAnchor(site, effectiveSelectors);
    const candidates = collectButtonCandidates();
    if (!candidates.length) return null;

    const best = candidates
      .map((element) => ({ element, score: scoreButtonCandidate(element, mode, editorAnchor) }))
      .sort((left, right) => right.score - left.score)[0];

    if (best?.score > 12) {
      logHeuristic(`${mode} heuristic matched`, site, best.score, best.element);
      return best.element;
    }

    return null;
  }

  async function findElement(type) {
    const site = getActiveSite();
    if (!shared.SUPPORTED_SITES.includes(site)) {
      return null;
    }

    const selectorSettings = await ensureSelectorSettingsLoaded();
    const effectiveSelectors = shared.getEffectiveSiteSelectors(site, selectorSettings);

    if (type === 'editor') {
      const directEditor = querySelectorList(effectiveSelectors.editors, isEditableElement);
      if (directEditor) return directEditor;
      const heuristicEditor = selectorSettings.heuristics.editor ? findEditorHeuristically(site) : null;
      if (!heuristicEditor) {
        window.AivoRelayManualPicker?.offer?.('editor');
      }
      return heuristicEditor;
    }

    if (type === 'sendButton') {
      const directSend = querySelectorList(effectiveSelectors.sendButtons, isButtonElement);
      if (directSend) return directSend;
      const heuristicSend = selectorSettings.heuristics.sendButton
        ? findButtonHeuristically(site, 'send', effectiveSelectors)
        : null;
      if (!heuristicSend) {
        window.AivoRelayManualPicker?.offer?.('sendButton');
      }
      return heuristicSend;
    }

    if (type === 'stopButton') {
      const directStop = querySelectorList(effectiveSelectors.stopButtons, isButtonElement);
      if (directStop) return directStop;
      const heuristicStop = selectorSettings.heuristics.stopButton
        ? findButtonHeuristically(site, 'stop', effectiveSelectors)
        : null;
      return heuristicStop;
    }

    return null;
  }

  window.AivoRelaySelectorManager = {
    ensureSelectorSettingsLoaded,
    getCachedSelectorSettings() {
      return selectorSettingsCache;
    },
    async findEditor() {
      return await findElement('editor');
    },
    async findSendButton() {
      return await findElement('sendButton');
    },
    async findStopButton() {
      return await findElement('stopButton');
    }
  };
})();
