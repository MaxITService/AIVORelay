'use strict';

(() => {
  const shared = window.AivoRelaySelectorShared;
  if (!shared) {
    return;
  }

  let selectorSettingsCache = shared.normalizeSelectorSettings(shared.DEFAULT_SELECTOR_SETTINGS);
  let selectorSettingsLoaded = false;
  let selectorSettingsPromise = null;
  let storageListenerRegistered = false;
  let stopDebugWatchTimer = null;

  const EDITOR_HINTS = {
    ChatGPT: ['prompt', 'composer', 'message', 'chat'],
    Perplexity: ['ask', 'search', 'message'],
    Gemini: ['message', 'prompt', 'ask'],
    Claude: ['message', 'prompt'],
    Grok: ['ask', 'grok', 'message'],
    AIStudio: ['prompt', 'run', 'message']
  };

  // "send"/"submit" are the real signal. "chat"/"enter" alone are weak: header controls
  // like "Temporary chat" or "New chat" carry them too.
  const SEND_STRONG_KEYWORDS = ['send', 'submit'];
  const SEND_WEAK_KEYWORDS = ['enter', 'chat'];
  const SEND_NEGATIVE_KEYWORDS = [
    'stop', 'group', 'cancel', 'attach', 'upload', 'file', 'image', 'photo', 'voice', 'mic',
    'temporary', 'new chat', 'history', 'menu', 'settings', 'search', 'close'
  ];
  const SEND_CONSENT_KEYWORDS = ['got it', 'accept', 'agree', 'cookie', 'consent', 'dismiss', 'no thanks'];
  // Configured selectors may target Cancel-style controls; heuristics only trust "stop".
  const STOP_SELECTOR_EXTRA_KEYWORDS = ['cancel', 'abort', 'pause', 'interrupt'];
  const STOP_NEGATIVE_KEYWORDS = ['send', 'submit', 'arrow', 'mic', 'upload', 'attach'];

  function logHeuristic(...args) {
    if (typeof logConCgp === 'function') {
      logConCgp('[selectors]', ...args);
    }
  }

  function hasActionLabel(element, keywords) {
    return window.ButtonsClickingShared?.hasActionLabel?.(element, keywords) === true;
  }

  function isInsidePageChrome(element) {
    return window.ButtonsClickingShared?.isInsidePageChrome?.(element) === true;
  }

  function getComposerScope(editorAnchor) {
    if (!editorAnchor) return null;
    return editorAnchor.closest?.('form') || editorAnchor;
  }

  function isNearComposer(element, scope) {
    const shared = window.ButtonsClickingShared;
    return shared?.isNearComposer ? shared.isNearComposer(element, scope) : true;
  }

  function getLabelParts(element) {
    return {
      ariaLabel: (element.getAttribute?.('aria-label') || '').toLowerCase(),
      title: (element.getAttribute?.('title') || '').toLowerCase(),
      testId: (element.getAttribute?.('data-testid') || '').toLowerCase(),
      text: (element.innerText || '').toLowerCase().trim()
    };
  }

  function isOurOverlayElement(element) {
    if (!element || typeof element.closest !== 'function') return false;
    return Boolean(
      element.closest('#hc-floating-ui') ||
      element.closest('.aivo-popup-root') ||
      element.closest('[data-aivorelay-popup="true"]')
    );
  }

  function isVisibleElement(element) {
    if (!element || isOurOverlayElement(element)) return false;
    if (window.MaxExtensionUtils?.isElementVisible) {
      return window.MaxExtensionUtils.isElementVisible(element);
    }
    const rect = element.getBoundingClientRect();
    if (!rect || rect.width < 2 || rect.height < 2) return false;
    const style = window.getComputedStyle(element);
    if (!style) return false;
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const opacity = Number.parseFloat(style.opacity || '1');
    return Number.isNaN(opacity) || opacity !== 0;
  }

  function isEditableElement(element) {
    if (!element || !isVisibleElement(element)) return false;
    if (element.closest?.('[inert], [aria-hidden="true"]')) return false;
    if (element instanceof HTMLTextAreaElement) {
      return !element.disabled && !element.readOnly;
    }
    const role = element.getAttribute?.('role') || '';
    const contentEditable = element.isContentEditable || element.getAttribute?.('contenteditable') === 'true';
    if (!contentEditable && role !== 'textbox') {
      return false;
    }
    if (element.getAttribute?.('aria-disabled') === 'true') return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 10 && rect.height > 10;
  }

  function isButtonElement(element) {
    if (!element || !isVisibleElement(element)) return false;
    const tag = element.tagName?.toLowerCase?.() || '';
    if (tag === 'button') return true;
    const role = element.getAttribute?.('role') || '';
    return role === 'button' || Boolean(element.getAttribute?.('onclick'));
  }

  function isDisabledElement(element) {
    if (!element) return true;
    return Boolean(
      element.disabled
      || element.getAttribute?.('disabled') !== null
      || element.getAttribute?.('aria-disabled') === 'true'
    );
  }

  function getElementTextMeta(element) {
    const values = [
      element.getAttribute?.('aria-label'),
      element.getAttribute?.('title'),
      element.getAttribute?.('placeholder'),
      element.getAttribute?.('data-testid'),
      element.getAttribute?.('name'),
      element.getAttribute?.('id'),
      element.textContent
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    return values;
  }

  function describeElement(element) {
    if (!(element instanceof Element)) return 'Unknown element';
    const tag = element.tagName.toLowerCase();
    const id = element.id ? `#${element.id}` : '';
    const testId = element.getAttribute('data-testid');
    const aria = element.getAttribute('aria-label');
    const text = (element.innerText || element.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 48);
    return [tag + id, testId && `data-testid="${testId}"`, aria && `aria="${aria}"`, text && `"${text}"`]
      .filter(Boolean)
      .join(' ');
  }

  function evaluateStopCandidate(element, details = {}) {
    const source = details.source || 'unknown';
    const selector = details.selector || '';
    const visible = isVisibleElement(element);
    const buttonLike = isButtonElement(element);
    const disabled = isDisabledElement(element);
    const textMeta = getElementTextMeta(element);
    const fromSelector = source === 'selector';
    // Word-level labels: a sidebar chat titled "Pin Stop Here" is not a Stop control.
    const hasStopSignal = hasActionLabel(
      element,
      fromSelector ? ['stop', ...STOP_SELECTOR_EXTRA_KEYWORDS] : ['stop']
    );
    const selectorSignal = fromSelector && typeof selector === 'string' && /(stop|cancel|abort|pause|interrupt)/i.test(selector);
    const sendLike = hasActionLabel(element, ['send', 'submit']);
    const reasons = [];

    if (!visible) reasons.push('not_visible');
    if (!buttonLike) reasons.push('not_button_like');
    if (disabled) reasons.push('disabled');
    if (isInsidePageChrome(element)) reasons.push('page_chrome');
    if (!hasStopSignal && !selectorSignal) reasons.push('no_stop_signal');
    if (!hasStopSignal && sendLike) reasons.push('send_like_text');
    if (!fromSelector && !isNearComposer(element, details.composerScope || null)) reasons.push('far_from_composer');

    return {
      element,
      source,
      selector,
      description: describeElement(element),
      textMeta,
      disabled,
      accepted: reasons.length === 0,
      reasons
    };
  }

  function collectShadowRoots(root, bucket) {
    const nodes = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (const node of nodes) {
      if (node?.shadowRoot) {
        bucket.push(node.shadowRoot);
        collectShadowRoots(node.shadowRoot, bucket);
      }
    }
  }

  function collectRoots() {
    const roots = [document];
    collectShadowRoots(document, roots);
    return roots;
  }

  function querySelectorList(selectors, filterFn, options = {}) {
    let fallback = null;
    for (const selector of selectors || []) {
      if (!selector) continue;
      let nodes = [];
      try {
        nodes = document.querySelectorAll(selector);
      } catch (err) {
        logHeuristic('Invalid selector skipped', selector, err?.message || err);
        continue;
      }
      for (const node of nodes) {
        if (filterFn && !filterFn(node)) continue;
        // Generic fallbacks can match a disabled twin before the live control.
        if (!options.preferEnabled || !isDisabledElement(node)) {
          return node;
        }
        fallback = fallback || node;
      }
    }
    return fallback;
  }

  function getActiveSite() {
    return window.InjectionTargetsOnWebsite?.activeSite || 'Unknown';
  }

  function registerStorageListener() {
    if (storageListenerRegistered || !chrome?.storage?.onChanged) return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.selectorSettings) return;
      selectorSettingsCache = shared.normalizeSelectorSettings(changes.selectorSettings.newValue);
      selectorSettingsLoaded = true;
    });
    storageListenerRegistered = true;
  }

  async function ensureSelectorSettingsLoaded() {
    registerStorageListener();
    if (selectorSettingsLoaded) {
      return selectorSettingsCache;
    }
    if (!selectorSettingsPromise) {
      selectorSettingsPromise = chrome.storage.local
        .get({ selectorSettings: shared.DEFAULT_SELECTOR_SETTINGS })
        .then(({ selectorSettings }) => {
          selectorSettingsCache = shared.normalizeSelectorSettings(selectorSettings);
          selectorSettingsLoaded = true;
          return selectorSettingsCache;
        })
        .catch(() => {
          selectorSettingsLoaded = true;
          return selectorSettingsCache;
        });
    }
    return selectorSettingsPromise;
  }

  function collectEditableCandidates() {
    const roots = collectRoots();
    const seen = new Set();
    const candidates = [];

    for (const root of roots) {
      const nodes = root.querySelectorAll
        ? root.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')
        : [];
      for (const node of nodes) {
        if (seen.has(node) || !isEditableElement(node)) continue;
        seen.add(node);
        candidates.push(node);
      }
    }

    return candidates;
  }

  function collectButtonCandidates() {
    const roots = collectRoots();
    const seen = new Set();
    const candidates = [];

    for (const root of roots) {
      const nodes = root.querySelectorAll
        ? root.querySelectorAll('button, [role="button"], div[onclick], span[onclick]')
        : [];
      for (const node of nodes) {
        if (seen.has(node) || !isButtonElement(node)) continue;
        seen.add(node);
        candidates.push(node);
      }
    }

    return candidates;
  }

  function scoreEditorCandidate(element, site) {
    const rect = element.getBoundingClientRect();
    const textMeta = getElementTextMeta(element);
    const hintKeywords = EDITOR_HINTS[site] || ['message', 'prompt', 'ask'];
    let score = 0;

    score += Math.min(rect.width, 900) / 22;
    score += Math.min(rect.height, 240) / 14;
    score += Math.max(0, rect.bottom) / 65;

    if (element instanceof HTMLTextAreaElement) score += 18;
    if (element.isContentEditable || element.getAttribute?.('contenteditable') === 'true') score += 20;
    if (element.getAttribute?.('role') === 'textbox') score += 8;
    if (element.closest?.('form')) score += 8;
    if (element.closest?.('footer, main, section')) score += 4;
    if (element.id === 'prompt-textarea') score += 40;
    if (textMeta.includes('prosemirror')) score += 20;
    if (textMeta.includes('lexical')) score += 12;

    for (const keyword of hintKeywords) {
      if (textMeta.includes(keyword)) {
        score += 12;
      }
    }

    if (textMeta.includes('search')) score -= 8;
    if (textMeta.includes('upload')) score -= 12;
    if (element.closest?.('header, nav, aside')) score -= 18;

    return score;
  }

  function findEditorHeuristically(site) {
    const candidates = collectEditableCandidates();
    if (!candidates.length) return null;

    const best = candidates
      .map((element) => ({ element, score: scoreEditorCandidate(element, site) }))
      .sort((left, right) => right.score - left.score)[0];

    if (best?.score > 18) {
      logHeuristic('Editor heuristic matched', site, best.score, best.element);
      return best.element;
    }

    return null;
  }

  function getEditorAnchor(site, effectiveSelectors) {
    return querySelectorList(effectiveSelectors.editors, isEditableElement) || findEditorHeuristically(site);
  }

  function includesAny(value, keywords) {
    return keywords.some((keyword) => value.includes(keyword));
  }

  function isInEditorForm(element, editorAnchor) {
    const form = editorAnchor?.closest?.('form');
    return Boolean(form && element.closest?.('form') === form);
  }

  // Heuristics click what they find, so an unlabeled icon next to the editor is not enough.
  function hasSendSignal(element, editorAnchor) {
    const { ariaLabel, title, testId, text } = getLabelParts(element);
    const caption = text.split('\n')[0].trim();
    return includesAny(ariaLabel, SEND_STRONG_KEYWORDS)
      || includesAny(title, SEND_STRONG_KEYWORDS)
      || includesAny(testId, SEND_STRONG_KEYWORDS)
      || ['send', 'submit', 'run'].includes(caption)
      || ariaLabel.trim() === 'run'
      || (element.getAttribute?.('type') === 'submit' && isInEditorForm(element, editorAnchor));
  }

  function scoreSendCandidate(element, editorAnchor) {
    const { ariaLabel, title, testId, text } = getLabelParts(element);
    let score = 0;

    if (includesAny(ariaLabel, SEND_STRONG_KEYWORDS)) score += 10;
    else if (includesAny(ariaLabel, SEND_WEAK_KEYWORDS)) score += 3;
    if (includesAny(title, SEND_STRONG_KEYWORDS)) score += 5;
    else if (includesAny(title, SEND_WEAK_KEYWORDS)) score += 2;
    if (includesAny(testId, SEND_STRONG_KEYWORDS)) score += 8;
    else if (includesAny(testId, SEND_WEAK_KEYWORDS)) score += 3;
    // First line only: icon-font buttons append glyph names like "keyboard_return".
    const caption = text.split('\n')[0].trim();
    if (caption === 'send' || caption === 'submit' || caption === 'run') score += 8;

    if (element.querySelector?.('svg')) score += 5;

    if (editorAnchor) {
      const rect = element.getBoundingClientRect();
      const editorRect = editorAnchor.getBoundingClientRect();
      const verticalDist = Math.abs(rect.top - editorRect.top);

      if (rect.bottom >= editorRect.top - 12 && rect.top <= editorRect.bottom + 12) score += 5;
      // Hugging the editor's right edge is the classic Send placement.
      if (verticalDist <= 60 && rect.left >= editorRect.right - 160 && rect.left <= editorRect.right + 60) score += 4;
      // Page header, sidebar and thread actions sit far from the composer.
      if (verticalDist > 250) score -= 15;
      if (rect.left >= editorRect.left) score += 3;
      if (rect.top > editorRect.top && rect.left > editorRect.left) score += 2;
      if (isInEditorForm(element, editorAnchor)) score += 5;
    }

    // An empty composer often keeps Send disabled.
    if (isDisabledElement(element)) score += 1;

    if (includesAny(ariaLabel, SEND_NEGATIVE_KEYWORDS)
      || includesAny(title, SEND_NEGATIVE_KEYWORDS)
      || includesAny(testId, SEND_NEGATIVE_KEYWORDS)) {
      score -= 50;
    }

    // Consent and cookie bars: "OK, got it", "Accept all", "I agree".
    const className = (typeof element.className === 'string' ? element.className : '').toLowerCase();
    if (SEND_CONSENT_KEYWORDS.some((keyword) => caption.includes(keyword) || className.includes(keyword) || ariaLabel.includes(keyword))) {
      score -= 50;
    }

    return score;
  }

  function scoreStopCandidate(element, editorAnchor) {
    const { ariaLabel, title, testId, text } = getLabelParts(element);
    const keywords = ['stop', 'cancel', 'abort', 'pause'];
    // A Stop label starts with the verb; a word buried in a chat title is weak evidence.
    const leadingKeyword = /^\s*(?:stop|cancel|abort|pause)\b/;
    const embeddedKeyword = /\b(?:stop|cancel|abort|pause)\b/;
    const keywordScore = (value, full) => (
      leadingKeyword.test(value) ? full : embeddedKeyword.test(value) ? Math.ceil(full / 4) : 0
    );
    let score = 0;

    score += keywordScore(ariaLabel, 10);
    score += keywordScore(title, 5);
    score += keywordScore(testId.replace(/[-_]/g, ' '), 8);
    if (keywords.includes(text)) score += 8;

    if (isInsidePageChrome(element)) score -= 50;

    if (element.querySelector?.('svg')) {
      const markup = element.innerHTML.toLowerCase();
      if (['rect', 'square', 'stop'].some((keyword) => markup.includes(keyword))) score += 5;
    }

    if (editorAnchor) {
      const rect = element.getBoundingClientRect();
      const editorRect = editorAnchor.getBoundingClientRect();
      const verticallyNear = rect.bottom >= editorRect.top && rect.top <= editorRect.bottom + 100;
      const horizontallyNear = rect.right >= editorRect.left - 200 && rect.left <= editorRect.right + 200;
      score += verticallyNear && horizontallyNear ? 3 : -30;
    }

    if (includesAny(ariaLabel, STOP_NEGATIVE_KEYWORDS)
      || includesAny(title, STOP_NEGATIVE_KEYWORDS)
      || includesAny(testId, STOP_NEGATIVE_KEYWORDS)) {
      score -= 50;
    }
    // Token counters and similar numeric badges.
    if (/^\d+$/.test(text)) score -= 20;

    return score;
  }

  function findSendButtonHeuristically(site, effectiveSelectors) {
    const editorAnchor = getEditorAnchor(site, effectiveSelectors);
    const best = collectButtonCandidates()
      .filter((element) => hasSendSignal(element, editorAnchor))
      .map((element) => ({ element, score: scoreSendCandidate(element, editorAnchor) }))
      .sort((left, right) => right.score - left.score)[0];

    if (best?.score > 0) {
      logHeuristic('send heuristic matched', site, best.score, best.element);
      return best.element;
    }

    return null;
  }

  function queryStopSelectorList(selectors) {
    const diagnostics = [];

    for (const selector of selectors || []) {
      if (!selector) continue;
      let nodes = [];
      try {
        nodes = document.querySelectorAll(selector);
      } catch (err) {
        diagnostics.push({
          element: null,
          source: 'selector-error',
          selector,
          description: 'Invalid selector',
          textMeta: '',
          disabled: false,
          accepted: false,
          reasons: ['invalid_selector', err?.message || 'query_failed']
        });
        logHeuristic('Invalid stop selector skipped', selector, err?.message || err);
        continue;
      }

      for (const node of nodes) {
        const result = evaluateStopCandidate(node, { source: 'selector', selector });
        diagnostics.push(result);
        if (result.accepted) {
          return { element: node, diagnostics };
        }
      }
    }

    return { element: null, diagnostics };
  }

  function inspectStopHeuristics(site, effectiveSelectors) {
    const editorAnchor = getEditorAnchor(site, effectiveSelectors);
    const composerScope = getComposerScope(editorAnchor);
    const diagnostics = collectButtonCandidates()
      .map((element) => {
        const evaluation = evaluateStopCandidate(element, { source: 'heuristic', composerScope });
        return {
          ...evaluation,
          score: scoreStopCandidate(element, editorAnchor)
        };
      })
      .sort((left, right) => (right.score || 0) - (left.score || 0))
      .slice(0, 12);

    const bestAccepted = diagnostics.find((entry) => entry.accepted && (entry.score || 0) > 0);
    return {
      element: bestAccepted?.element || null,
      diagnostics
    };
  }

  async function inspectStopButtons(siteOverride = null) {
    const site = siteOverride || getActiveSite();
    if (!shared.SUPPORTED_SITES.includes(site)) {
      return [];
    }

    const selectorSettings = await ensureSelectorSettingsLoaded();
    const effectiveSelectors = shared.getEffectiveSiteSelectors(site, selectorSettings);
    const direct = queryStopSelectorList(effectiveSelectors.stopButtons);
    const heuristic = selectorSettings.heuristics.stopButton
      ? inspectStopHeuristics(site, effectiveSelectors)
      : { element: null, diagnostics: [] };

    return [...direct.diagnostics, ...heuristic.diagnostics].map((entry, index) => ({
      index: index + 1,
      source: entry.source,
      selector: entry.selector || '',
      accepted: entry.accepted,
      disabled: entry.disabled,
      score: entry.score ?? null,
      reasons: Array.isArray(entry.reasons) ? entry.reasons.join(', ') : '',
      description: entry.description,
      textMeta: entry.textMeta
    }));
  }

  async function findElement(type, options = {}) {
    const site = getActiveSite();
    if (!shared.SUPPORTED_SITES.includes(site)) {
      return null;
    }

    const selectorSettings = await ensureSelectorSettingsLoaded();
    const effectiveSelectors = shared.getEffectiveSiteSelectors(site, selectorSettings);

    if (type === 'editor') {
      const directEditor = querySelectorList(effectiveSelectors.editors, isEditableElement);
      if (directEditor) return directEditor;
      const heuristicEditor = selectorSettings.heuristics.editor ? findEditorHeuristically(site) : null;
      if (!heuristicEditor) {
        window.AivoRelayManualPicker?.offer?.('editor');
      }
      return heuristicEditor;
    }

    if (type === 'sendButton') {
      const directSend = querySelectorList(effectiveSelectors.sendButtons, isButtonElement, { preferEnabled: true });
      if (directSend) return directSend;
      const heuristicSend = selectorSettings.heuristics.sendButton
        ? findSendButtonHeuristically(site, effectiveSelectors)
        : null;
      // Auto-send polls this; it offers the picker itself once polling gives up.
      if (!heuristicSend && options.offerPicker !== false) {
        window.AivoRelayManualPicker?.offer?.('sendButton');
      }
      return heuristicSend;
    }

    if (type === 'stopButton') {
      const directStop = queryStopSelectorList(effectiveSelectors.stopButtons);
      if (directStop.element) {
        logHeuristic('Stop selector matched', site, directStop.diagnostics.find((entry) => entry.accepted)?.description || 'selector');
        return directStop.element;
      }
      const heuristicStop = selectorSettings.heuristics.stopButton
        ? inspectStopHeuristics(site, effectiveSelectors).element
        : null;
      if (heuristicStop) {
        logHeuristic('Stop heuristic matched', site, describeElement(heuristicStop));
      }
      return heuristicStop;
    }

    return null;
  }

  window.AivoRelaySelectorManager = {
    ensureSelectorSettingsLoaded,
    getCachedSelectorSettings() {
      return selectorSettingsCache;
    },
    shouldIgnoreStopButton() {
      return selectorSettingsCache?.heuristics?.ignoreStopButton === true;
    },
    async findEditor() {
      return await findElement('editor');
    },
    async findSendButton(options) {
      return await findElement('sendButton', options);
    },
    async findStopButton() {
      return await findElement('stopButton');
    },
    async inspectStopButtons(siteOverride) {
      return await inspectStopButtons(siteOverride);
    }
  };

  window.AivoRelayStopButtonDebug = {
    async inspect(siteOverride) {
      return await inspectStopButtons(siteOverride);
    },
    async log(siteOverride) {
      const entries = await inspectStopButtons(siteOverride);
      console.group('[aivo-relay] Stop button diagnostics');
      console.table(entries);
      console.groupEnd();
      return entries;
    },
    watch(intervalMs = 1000, siteOverride) {
      const delay = Math.max(250, Number(intervalMs) || 1000);
      if (stopDebugWatchTimer) {
        clearInterval(stopDebugWatchTimer);
      }
      stopDebugWatchTimer = setInterval(() => {
        void this.log(siteOverride);
      }, delay);
      return { ok: true, intervalMs: delay };
    },
    stop() {
      if (stopDebugWatchTimer) {
        clearInterval(stopDebugWatchTimer);
        stopDebugWatchTimer = null;
      }
      return { ok: true };
    }
  };
  window.inspectAivoRelayStopButtons = (...args) => window.AivoRelayStopButtonDebug.inspect(...args);
})();
