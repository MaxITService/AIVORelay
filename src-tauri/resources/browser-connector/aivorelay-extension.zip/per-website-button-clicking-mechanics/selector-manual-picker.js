'use strict';

(() => {
  const shared = window.AivoRelaySelectorShared;
  if (!shared) {
    return;
  }

  const OFFER_COOLDOWN_MS = 15000;
  const TYPE_LABELS = {
    editor: 'editor',
    sendButton: 'send button',
    stopButton: 'stop button'
  };
  const TYPE_SELECTOR_KEY = {
    editor: 'editors',
    sendButton: 'sendButtons',
    stopButton: 'stopButtons'
  };

  let activeSession = null;
  const lastOffers = {
    editor: 0,
    sendButton: 0,
    stopButton: 0
  };

  function getActiveSite() {
    return window.InjectionTargetsOnWebsite?.activeSite || 'Unknown';
  }

  function isSupportedSite(site) {
    return shared.SUPPORTED_SITES.includes(site);
  }

  function escapeCss(value) {
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
      return CSS.escape(value);
    }
    return String(value).replace(/"/g, '\\"');
  }

  function isUniqueSelector(selector) {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }

  function deriveSelectorFromElement(element) {
    if (!element?.tagName) return null;
    const tag = element.tagName.toLowerCase();

    const id = element.getAttribute('id');
    if (id) {
      const candidate = `#${escapeCss(id)}`;
      if (isUniqueSelector(candidate)) return candidate;
    }

    const attrPriority = ['data-testid', 'aria-label', 'name', 'placeholder'];
    for (const attr of attrPriority) {
      const value = element.getAttribute(attr);
      if (!value) continue;
      const candidate = `${tag}[${attr}="${escapeCss(value)}"]`;
      if (isUniqueSelector(candidate)) return candidate;
    }

    const classes = Array.from(element.classList || [])
      .filter((className) => className && className.length > 1 && !className.startsWith('hc-'))
      .slice(0, 3);
    if (classes.length) {
      const candidate = `${tag}.${classes.map(escapeCss).join('.')}`;
      if (isUniqueSelector(candidate)) return candidate;
    }

    const segments = [];
    let node = element;
    for (let depth = 0; node?.tagName && depth < 4; depth += 1) {
      const parent = node.parentElement;
      if (!parent) break;
      const siblings = Array.from(parent.children).filter((child) => child.tagName === node.tagName);
      const index = siblings.indexOf(node) + 1;
      segments.unshift(`${node.tagName.toLowerCase()}:nth-of-type(${index})`);
      const candidate = segments.join(' > ');
      if (isUniqueSelector(candidate)) return candidate;
      node = parent;
    }

    return null;
  }

  function getCandidateFromPoint(targetType, eventTarget) {
    if (!(eventTarget instanceof Element)) return null;
    if (eventTarget.closest('#toastContainer, #hc-floating-ui')) return null;

    if (targetType === 'editor') {
      return eventTarget.closest('textarea, [contenteditable="true"], [role="textbox"]');
    }

    return eventTarget.closest('button, [role="button"], div[onclick], span[onclick]');
  }

  function clearHighlight() {
    if (!activeSession?.highlightedElement) return;
    const previous = activeSession.highlightedElement;
    previous.style.outline = activeSession.previousOutline || '';
    previous.style.outlineOffset = activeSession.previousOutlineOffset || '';
    activeSession.highlightedElement = null;
    activeSession.previousOutline = '';
    activeSession.previousOutlineOffset = '';
  }

  function highlightElement(element) {
    if (!activeSession) return;
    if (activeSession.highlightedElement === element) return;

    clearHighlight();

    if (!element) return;
    activeSession.highlightedElement = element;
    activeSession.previousOutline = element.style.outline;
    activeSession.previousOutlineOffset = element.style.outlineOffset;
    element.style.outline = '3px solid #a855f7';
    element.style.outlineOffset = '3px';
  }

  function stopPickMode() {
    if (!activeSession) return;
    clearHighlight();
    document.removeEventListener('mousemove', activeSession.onMouseMove, true);
    document.removeEventListener('click', activeSession.onClick, true);
    document.removeEventListener('keydown', activeSession.onKeyDown, true);
    activeSession = null;
  }

  async function savePickedSelector(targetType, element) {
    const site = getActiveSite();
    if (!isSupportedSite(site)) {
      return { ok: false, reason: 'unsupportedSite' };
    }

    const selector = deriveSelectorFromElement(element);
    if (!selector) {
      return { ok: false, reason: 'selectorNotDerived' };
    }

    const { selectorSettings } = await chrome.storage.local.get({
      selectorSettings: shared.DEFAULT_SELECTOR_SETTINGS
    });
    const normalized = shared.normalizeSelectorSettings(selectorSettings);
    const selectorKey = TYPE_SELECTOR_KEY[targetType];
    if (!selectorKey) {
      return { ok: false, reason: 'unknownType' };
    }

    const existingSite = normalized.customSelectors[site] || shared.normalizeSiteSelectors({});
    const updatedSite = {
      ...existingSite,
      [selectorKey]: shared.mergeSelectorLists([selector], existingSite[selectorKey])
    };

    await chrome.storage.local.set({
      selectorSettings: {
        ...normalized,
        customSelectors: {
          ...normalized.customSelectors,
          [site]: updatedSite
        }
      }
    });

    return { ok: true, selector, site };
  }

  async function start(targetType) {
    if (!TYPE_LABELS[targetType]) return false;

    stopPickMode();

    const session = {
      targetType,
      highlightedElement: null,
      previousOutline: '',
      previousOutlineOffset: '',
      onMouseMove: (event) => {
        const candidate = getCandidateFromPoint(targetType, event.target);
        highlightElement(candidate);
      },
      onClick: async (event) => {
        const candidate = getCandidateFromPoint(targetType, event.target);
        if (!candidate) {
          return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        const result = await savePickedSelector(targetType, candidate);
        stopPickMode();

        if (result.ok) {
          showToast(
            `Saved ${TYPE_LABELS[targetType]} selector for ${result.site}. Resend the message to use it.`,
            'success',
            {
              duration: 5000,
              tooltip: result.selector
            }
          );
        } else {
          showToast(
            `Could not save the ${TYPE_LABELS[targetType]} selector automatically. Try the Settings tab.`,
            'error',
            5000
          );
        }
      },
      onKeyDown: (event) => {
        if (event.key !== 'Escape') return;
        event.preventDefault();
        stopPickMode();
        showToast('Manual picker cancelled.', 'info', 2500);
      }
    };

    activeSession = session;
    document.addEventListener('mousemove', session.onMouseMove, true);
    document.addEventListener('click', session.onClick, true);
    document.addEventListener('keydown', session.onKeyDown, true);

    showToast(
      `Pick the ${TYPE_LABELS[targetType]} on the page. Hover to preview, click to save, Esc to cancel.`,
      'info',
      {
        duration: 6500,
        tooltip: 'The click is intercepted by AivoRelay while picker mode is active, so the page action will not fire.'
      }
    );

    return true;
  }

  function offer(targetType) {
    if (!TYPE_LABELS[targetType] || typeof showToast !== 'function') {
      return false;
    }

    const now = Date.now();
    if (now - lastOffers[targetType] < OFFER_COOLDOWN_MS) {
      return false;
    }
    lastOffers[targetType] = now;

    showToast(
      `AivoRelay could not find the ${TYPE_LABELS[targetType]}. You can pick it manually once and save it for this site.`,
      'info',
      {
        duration: 0,
        tooltip: 'Use this if the website changed its DOM and the default selectors no longer match.',
        customButtons: [
          {
            text: 'Pick now',
            title: `Choose the ${TYPE_LABELS[targetType]} on this page`,
            onClick: async () => {
              await start(targetType);
              return true;
            }
          },
          {
            text: 'Later',
            title: 'Dismiss this helper',
            onClick: () => true
          }
        ]
      }
    );

    return true;
  }

  window.AivoRelayManualPicker = {
    offer,
    start,
    stop: stopPickMode
  };
})();
