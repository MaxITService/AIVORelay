'use strict';

const PAGE_CHROME_SELECTOR =
  'nav, aside, a[href], [role="navigation"], [role="menu"], [role="menuitem"], [role="listbox"], [role="tablist"]';

window.ButtonsClickingShared = {
  isVisibleInteractiveElement(el) {
    if (!el || !el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    const style = window.getComputedStyle(el);
    if (!style) return false;
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  },

  /**
   * Word-level label check. A substring test matched sidebar chat titles
   * ("Pin Stop Here") and any wrapper whose content mentioned the word.
   * Labels and captions must start with a keyword; data-testid must carry it as a token.
   */
  hasActionLabel(el, actionKeywords) {
    if (!el?.getAttribute || !actionKeywords?.length) return false;
    const keywords = actionKeywords.join("|");
    const leading = new RegExp(`^\\s*(?:${keywords})\\b`, "i");
    const token = new RegExp(`(?:^|[-_:.\\s])(?:${keywords})(?:[-_:.\\s]|$)`, "i");
    // Icon-font glyph names ("progress_activity", "stop_circle") render as text; drop leading
    // snake_case tokens so the visible caption ("Stop") is what gets tested.
    const caption = (el.innerText || "").trim().replace(/^(?:[a-z0-9]+(?:_[a-z0-9]+)+\s*)+/i, "");
    // A real Stop control carries a short caption; long text means a wrapper around content.
    const shortCaption = caption.length <= 40 ? caption : "";
    return leading.test(el.getAttribute("aria-label") || "")
      || leading.test(el.getAttribute("title") || "")
      || token.test(el.getAttribute("data-testid") || "")
      || leading.test(shortCaption);
  },

  hasStopLabel(el, extraKeywords = []) {
    return window.ButtonsClickingShared.hasActionLabel(el, ["stop", ...extraKeywords]);
  },

  // Sidebars, menus and links never host the generation Stop control.
  isInsidePageChrome(el) {
    return !!el?.closest?.(PAGE_CHROME_SELECTOR);
  },

  // The composer region: the editor's form, or the editor itself when there is none.
  getComposerScope(editor = null) {
    if (editor) return editor.closest?.("form") || editor;
    for (const selector of getSelectors("editors")) {
      let found = null;
      try {
        found = Array.from(document.querySelectorAll(selector)).find((node) => this.isVisibleInteractiveElement(node));
      } catch {
        // Invalid selector.
      }
      if (found) return found.closest("form") || found;
    }
    return null;
  },

  // True when the element sits inside the composer scope or within a margin of it.
  // An unknown scope cannot veto anything.
  isNearComposer(el, scope, margin = 200) {
    if (!scope || !el) return true;
    if (scope.contains(el)) return true;
    const a = el.getBoundingClientRect();
    const b = scope.getBoundingClientRect();
    const edges = [a.left, a.right, a.top, a.bottom, b.left, b.right, b.top, b.bottom];
    if (!edges.every(Number.isFinite)) return true;
    return a.right >= b.left - margin && a.left <= b.right + margin
      && a.bottom >= b.top - margin && a.top <= b.bottom + margin;
  },

  isBusyStopButton(btn) {
    return window.ButtonsClickingShared.hasStopLabel(btn);
  },

  async findEditor() {
    if (window.AivoRelaySelectorManager?.findEditor) {
      return await window.AivoRelaySelectorManager.findEditor();
    }
    return findFirstVisible(getSelectors("editors"));
  },

  async findSendButton(options = {}) {
    if (window.AivoRelaySelectorManager?.findSendButton) {
      return await window.AivoRelaySelectorManager.findSendButton(options);
    }
    return findFirstVisible(getSelectors("sendButtons"), { preferEnabled: true });
  },

  /**
   * Finds a visible Stop control: the site's custom finder first, then configured selectors,
   * then the selector manager heuristics.
   */
  async findStopButton(customFinder = null) {
    if (window.AivoRelaySelectorManager?.shouldIgnoreStopButton?.()) {
      return null;
    }
    if (typeof customFinder === "function") {
      const custom = await customFinder();
      if (this.isVisibleInteractiveElement(custom)) return custom;
    }
    if (window.AivoRelaySelectorManager?.findStopButton) {
      return await window.AivoRelaySelectorManager.findStopButton();
    }
    return findFirstVisible(getSelectors("stopButtons"), {
      filter: (node) => defaultIsEnabled(node) && !this.isInsidePageChrome(node)
    });
  },

  /**
   * Auto-send with Stop awareness. Paste-first: a visible Stop control ends the run as "busy"
   * instead of waiting for generation to finish.
   * Returns { status: "sent" | "busy" | "send_not_found", reason?, button? }.
   * clickAction may return false to reject the click; the loop then retries.
   */
  async performAutoSend(options = {}) {
    const {
      findButton = () => this.findSendButton({ offerPicker: false }),
      findStopButton = null,
      isBusy = (btn) => this.isBusyStopButton(btn),
      isEnabled = defaultIsEnabled,
      preClickValidation = () => true,
      clickAction = (btn) => window.MaxExtensionUtils.simulateClick(btn),
      stopConfirmationDelay = 0,
      readyConfirmationDelay = 0,
      interval = 150,
      maxAttempts = 20
    } = options;

    const initialUrl = location.href;
    const findStop = () => this.findStopButton(findStopButton);
    const busy = (button) => {
      if (window.AivoRelayStopButtonDebug?.inspect) {
        window.AivoRelayStopButtonDebug.inspect().then((entries) => {
          logConCgp("[buttons] Auto-send blocked by stop button diagnostics:", entries);
        }).catch(() => {});
      }
      return { status: "busy", button };
    };

    let lastFailure = "missing";
    let readySince = 0;

    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (location.href !== initialUrl) {
        return { status: "send_not_found", reason: "page_navigated" };
      }

      const stopButton = await findStop();
      if (stopButton) {
        if (stopConfirmationDelay <= 0) return busy(stopButton);
        // A Send control can briefly look like Stop while the page swaps it; confirm first.
        await sleep(stopConfirmationDelay);
        const confirmedStop = await findStop();
        if (confirmedStop) return busy(confirmedStop);
        readySince = 0;
      }

      const sendButton = await findButton();
      if (!sendButton) {
        lastFailure = "missing";
        readySince = 0;
      } else if (isBusy(sendButton)) {
        // Some sites reuse one element for Send and Stop.
        return busy(sendButton);
      } else if (!isEnabled(sendButton)) {
        lastFailure = "disabled";
        readySince = 0;
      } else if (!(await preClickValidation(sendButton))) {
        lastFailure = "validation_failed";
        readySince = 0;
      } else {
        if (!readySince) readySince = Date.now();
        if (Date.now() - readySince >= readyConfirmationDelay) {
          // Stop can replace Send between polling ticks; check again right before the click.
          const stopBeforeClick = await findStop();
          if (stopBeforeClick) return busy(stopBeforeClick);
          if (location.href !== initialUrl) {
            return { status: "send_not_found", reason: "page_navigated" };
          }
          if (sendButton.isConnected && isEnabled(sendButton) && !isBusy(sendButton)) {
            let clicked;
            try {
              clicked = await clickAction(sendButton);
            } catch (err) {
              logConCgp("[buttons] Auto-send click failed:", err?.message || err);
              return { status: "send_not_found", reason: "click_error" };
            }
            if (clicked !== false) {
              return { status: "sent", button: sendButton };
            }
          }
          lastFailure = "click_rejected";
          readySince = 0;
        }
      }

      await sleep(interval);
    }

    if (lastFailure === "missing") {
      window.AivoRelayManualPicker?.offer?.("sendButton");
    }
    return { status: "send_not_found", reason: lastFailure };
  }
};

function getSelectors(key) {
  const selectors = window.InjectionTargetsOnWebsite?.selectors?.[key];
  return Array.isArray(selectors) ? selectors : [];
}

function findFirstVisible(selectors, options = {}) {
  const filter = typeof options.filter === "function" ? options.filter : null;
  let fallback = null;
  for (const selector of selectors) {
    if (!selector) continue;
    let nodes = [];
    try {
      nodes = document.querySelectorAll(selector);
    } catch (err) {
      logConCgp("[buttons] Invalid selector skipped:", selector, err?.message || err);
      continue;
    }
    for (const node of nodes) {
      if (!window.MaxExtensionUtils.isElementVisible(node)) continue;
      if (filter && !filter(node)) continue;
      if (!options.preferEnabled || defaultIsEnabled(node)) return node;
      fallback = fallback || node;
    }
  }
  return fallback;
}

function defaultIsEnabled(button) {
  if (!button) return false;
  if (button.disabled) return false;
  const ariaDisabled = button.getAttribute("aria-disabled");
  return ariaDisabled !== "true";
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
